// Shana Slavin
// CPSC1010, 001
// Due April 7, 2017
// Lab 10
// has #include statements and prototypes

#include <stdio.h>

#define SIZE 20

void initialize(int a[]);
void all(int a[]);
void even(int a[]);
void odd(int a[]);
void fib(int a []);
void printArray(int a[]);
int innerProduct(int a[], int b[]);
